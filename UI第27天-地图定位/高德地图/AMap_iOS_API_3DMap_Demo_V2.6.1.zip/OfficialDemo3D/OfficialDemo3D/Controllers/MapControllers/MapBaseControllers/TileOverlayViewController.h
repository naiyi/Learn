//
//  TileOverlayViewController.h
//  OfficialDemo3D
//
//  Created by Li Fei on 3/3/14.
//  Copyright (c) 2014 songjian. All rights reserved.
//

#import "BaseMapViewController.h"

@interface TileOverlayViewController : BaseMapViewController

@end
