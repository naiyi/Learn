//
//  HeatMapTileOverlayViewController.h
//  DevDemo2D
//
//  Created by 翁乐 on 15/5/12.
//  Copyright (c) 2015年 xiaoming han. All rights reserved.
//

#import "BaseMapViewController.h"

@interface HeatMapTileOverlayViewController : BaseMapViewController

@end
