//
//  LocalTileOverlay.h
//  DevDemo2D
//
//  Created by xiaoming han on 15/1/13.
//  Copyright (c) 2015年 xiaoming han. All rights reserved.
//

#import <MAMapKit/MAMapKit.h>

@interface LocalTileOverlay : MATileOverlay

@end
