//
//  AppDelegate.h
//  PushNotfication
//
//  Created by  ZhuHong on 2017/2/21.
//  Copyright © 2017年 CoderHG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

