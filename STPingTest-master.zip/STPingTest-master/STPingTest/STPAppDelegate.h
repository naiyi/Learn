//
//  STPAppDelegate.h
//  STPingTest
//
//  Created by SunJiangting on 15-3-19.
//  Copyright (c) 2015年 Suen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

