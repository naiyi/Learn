//
//  main.m
//  STPingTest
//
//  Created by SunJiangting on 15-3-19.
//  Copyright (c) 2015年 Suen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STPAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([STPAppDelegate class]));
    }
}
